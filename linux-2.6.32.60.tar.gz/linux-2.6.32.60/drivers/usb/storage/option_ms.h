#ifndef _OPTION_MS_H_
#define _OPTION_MS_H_
extern int option_ms_init(struct us_data *us);
#endif
